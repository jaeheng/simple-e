<?php
/**
 * 页面底部信息
 */
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>

<div class="footer">
    <div class="container">
        &copy; 2017 Copyright <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
        <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
        Powered By <a href="http://www.emlog.net" target="_blank">emlog</a>
        <span class="pull-right">Theme by <a href="http://www.zhangziheng.com" target="_blank">jaeheng</a></span>
    </div>
</div>

<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
<script>$(function(){var n=function(n){n.fadeOut(100)},o=function(n){n.fadeIn(100)};$(document).on("click","[v-show]",function(n){n.preventDefault(),n.stopPropagation(),o($("#"+$(this).attr("v-show")))}),$(document).on("click",function(o){n($("#menu")),n($("#keyword"))}),$(document).on("click",".icon-close",function(o){n($(this).parents(".toggle"))}),$(document).on("click","#menu",function(n){n.stopPropagation()}),$(document).on("click","#keyword",function(n){n.stopPropagation()})});</script>
</body>
</html>