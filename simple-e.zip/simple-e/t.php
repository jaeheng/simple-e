<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
die('<p style="text-align: center; padding: 4em 0;">碎语功能不可用!</p>');