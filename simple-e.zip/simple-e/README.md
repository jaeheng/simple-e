# Simple-E

这是一个[emlog](http://www.emlog.net)模板， 这个模板非常简洁。